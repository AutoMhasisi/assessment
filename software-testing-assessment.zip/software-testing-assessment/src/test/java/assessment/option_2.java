package assessment;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class option_2 {
	
	WebDriver driver;
	
	

	@BeforeMethod
	void setUp()
	{
		//System.setProperty("webdriver.chrome.driver", "//Users//tmpofu//Desktop//Eclipse Test Automation//chromedriver");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}
	
	
	
	@Test(priority=1)
	void buyItems()
	
	{
		//username
		driver.findElement(By.xpath("//*[@id=\"user-name\"]")).clear();
		driver.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys("standard_user");
		
		//password
		driver.findElement(By.id("password")).clear();
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		
		//login button
		driver.findElement(By.cssSelector("#login-button")).click();
		
		//adding items to cart
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();
		driver.findElement(By.name("add-to-cart-sauce-labs-bolt-t-shirt")).click();
		
		//clicking on cart
		driver.findElement(By.className("shopping_cart_link")).click();
		
		
		//validating cart items
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText(), "Sauce Labs Backpack");
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"item_1_title_link\"]/div")).getText(), "Sauce Labs Bolt T-Shirt");
		
		//clicking checkout button
		driver.findElement(By.id("checkout")).click();
		
		
		
		
	
	}
	
	@Test(priority=2)
	void checkout()
	{
		
//entering checkout information
	driver.findElement(By.id("first-name")).sendKeys("Nonte");
	driver.findElement(By.name("lastName")).sendKeys("Mtshingila");
	driver.findElement(By.id("postal-code")).sendKeys("0158");
	driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		
	}
	
	
	@Test (dependsOnMethods = {"checkout"})
	void checkoutOverview()
	{
		String price1 = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[4]/div[2]/div[2]/div")).getText();
		String price2 = driver.findElement(By.xpath("#checkout_summary_container > div > div.cart_list > div:nth-child(3) > div.cart_item_label > div.item_pricebar > div")).getText();
		String price3 = driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[5]")).getText();
		
		
		
	
		
	}
	
	@Test (dependsOnMethods = {"checkoutOverview"})
	void orderComplete()
	{
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"header_container\"]/div[2]/span")).getText(), "Checkout: Complete!");
	}

	
	
	@AfterMethod
	void tearDown()
	{
	
		//driver.quit();
	}
}
