Setup the project using Eclipse IDE
Used testNG to run the test cases
Used Maven build tool for resources plugin
Using testNG reports under the test-output folder
Can also run the testNG test cases in Maven using testNG.xml