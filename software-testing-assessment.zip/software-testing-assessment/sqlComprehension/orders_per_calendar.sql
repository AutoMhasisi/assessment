select count(*) from orders where to_char(order_date, 'yyyy') = '1996' ;
